package com.itams.visionet.customerserviceapps.rest;

/**
 * Created by Januar on 3/31/2017.
 */

public class ApiClientLogin {
}
